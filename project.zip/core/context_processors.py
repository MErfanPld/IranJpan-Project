from .forms import SearchForm

def search_form(request):
    return {
        'search_form': SearchForm(request.GET or None)
    }

def redirect_to(request):
    return {'redirect_to': request.path}